import Foundation
import UIKit

//Class for swift playground live view
public class WorldView: UIView {
    var world: World = World(size: 100)
    var cellSize: Int = 10
    
    public convenience init(worldSize: Int, cellSize: Int) {
        let frame = CGRect(x: 0, y: 0, width: worldSize * cellSize, height: worldSize * cellSize)
        self.init(frame: frame)
        self.world = World(size: worldSize)
        self.cellSize = cellSize
    }
    
    public convenience init() {
        let frame = CGRect(x: 0, y: 0, width: 1000, height: 1000)
        self.init(frame: frame)
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func draw(_ rect: CGRect) {
        
        let context = UIGraphicsGetCurrentContext()
        context?.saveGState()
        
        for cell in world.cells {
          let rect = CGRect(x: cell.x * cellSize, y: cell.y * cellSize, width: cellSize, height: cellSize)
            let color = cell.state == .alive ? UIColor.black.cgColor : UIColor.white.cgColor
            context?.addRect(rect)
            context?.setFillColor(color)
            context?.fill(rect)
        }
        context?.restoreGState()
    }
    
    //override touchbegins to capture the touch event in the live view
    //this will then udate the cells in the live view to the next generation and apply the game rules
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        world.updateCells()
        //tells the view to redraw its content calling draw function
        setNeedsDisplay()
    }
}
