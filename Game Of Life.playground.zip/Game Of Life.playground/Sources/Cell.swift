import Foundation

//Create an object type State which is either dead or alive
public enum State {
    case alive
    case dead
}

//Cell variables and initialisation
//Using struct means they cannot be changed
//Structs in swift would usually give a init, but not in Playgrounds
public struct Cell {
    public let x: Int
    public let y: Int
    public var state: State
    
    //Prepare instance of Cell struct for use
    //Sets initial value for each stored property
    //Self refers to the current instance within the init method
    init(x: Int, y: Int, state: State) {
        self.x = x
        self.y = y
        self.state = state
    }
    
    //Give the cell the ability to tell if its a neighbour
    //Take the co-ordinates of both cells and check if they are next to each other
    public func isNeighbor(to cell: Cell) -> Bool {

        //Calculate x and y coordinate difference between two cells
        let xDelta = abs(self.x - cell.x)
        let yDelta = abs(self.y - cell.y)

        //Compare x and y coordinates to see if they are 1 point away on either axis
        //If 1 point away return true, if not retun false
        if ((xDelta,yDelta) == (1,1)) || ((xDelta,yDelta) == (0,1)) || ((xDelta,yDelta) == (1,0)) {
            return true
        }
        else {
            return false
        }

    }
}


