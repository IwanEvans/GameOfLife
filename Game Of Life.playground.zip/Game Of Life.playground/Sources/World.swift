import Foundation

public class World {
    public var cells = [Cell]()
    public let size: Int
    
    public init(size: Int) {
        self.size = size
        
        //cells populate world
        //iterates using half-open range operator in range 0 up to but not including last value of size
        for x in 0..<size {
            for y in 0..<size {
                let randomState = arc4random_uniform(3)
                let cell = Cell(x: x, y: y, state: randomState == 0 ? .alive : .dead)
                cells.append(cell)
            }
        }
    }
    
    
    public func updateCells() {
        //temporary array that will hold our updated cells
        var updatedCells = [Cell]()
        //filters out all the dead cells so dont have to loop over them later
        let liveCells = cells.filter {$0.state == .alive}
        
        for cell in cells {
            //grab living neighbours using the function on Cell
            let livingNeighbors = liveCells.filter { $0.isNeighbor(to: cell) }
            
            //if the cell is alive and the number of neighbours is two or three it lives to next generation
            if (livingNeighbors.count == 2 || livingNeighbors.count == 3) && cell.state == .alive {
                updatedCells.append(cell)
            }
            //if the cell is dead and has three live neighbours, it becomes alive
            if livingNeighbors.count > 3 && cell.state == .dead {
                let liveCell = Cell(x: cell.x, y: cell.y, state: .alive)
                updatedCells.append(liveCell)
            }
            else {
                //if not the above then add a dead cell to the updated cells
                let deadCell = Cell(x: cell.x, y: cell.y, state: .dead)
                updatedCells.append(deadCell)
            }
        }
        
        cells = updatedCells
    }
}
