import UIKit
import PlaygroundSupport
 

let view = WorldView(worldSize: 30, cellSize: 20)
PlaygroundPage.current.liveView = view


